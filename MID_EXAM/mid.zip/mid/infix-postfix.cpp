#include <iostream>
#include <stack>
using namespace std;

// Function to check precedence
int precedence(char op) {
    if(op == '+' || op == '-')
        return 1;
    if(op == '*' || op == '/')
        return 2;
    return 0;
}

// Infix to Postfix
string infixToPostfix(string infix) {
    stack<char> st;
    string postfix = "";

    for(int i = 0; i < infix.length(); i++) {
        char ch = infix[i];

        // If operand, add to output
        if(isalnum(ch))
            postfix += ch;

        // If '(', push
        else if(ch == '(')
            st.push(ch);

        // If ')', pop until '('
        else if(ch == ')') {
            while(!st.empty() && st.top() != '(') {
                postfix += st.top();
                st.pop();
            }
            st.pop(); // remove '('
        }

        // If operator
        else {
            while(!st.empty() && precedence(st.top()) >= precedence(ch)) {
                postfix += st.top();
                st.pop();
            }
            st.push(ch);
        }
    }

    // Pop remaining operators
    while(!st.empty()) {
        postfix += st.top();
        st.pop();
    }

    return postfix;
}

// Postfix to Prefix
string postfixToPrefix(string postfix) {
    stack<string> st;

    for(int i = 0; i < postfix.length(); i++) {
        char ch = postfix[i];

        // If operand
        if(isalnum(ch)) {
            string s(1, ch);
            st.push(s);
        }
        // If operator
        else {
            string op1 = st.top(); st.pop();
            string op2 = st.top(); st.pop();

            string temp = ch + op2 + op1;
            st.push(temp);
        }
    }

    return st.top();
}

int main() {
    string infix = "(A+B)*(C-D)+C";

    string postfix = infixToPostfix(infix);
    cout << "Postfix Expression: " << postfix << endl;

    string prefix = postfixToPrefix(postfix);
    cout << "Prefix Expression: " << prefix << endl;

    return 0;
}