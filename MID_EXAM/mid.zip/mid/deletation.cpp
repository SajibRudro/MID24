#include <bits/stdc++.h>
using namespace std;

void deletion(int la[], int n, int k, int item)
{
    int j = k;
    while (j < n - 1)
    {
        la[j] = la[j + 1];
        j++;
    }

    for (int x = 0; x < n - 1; x++)
    {
        cout << la[x] << " ";
    }
}
int main()
{
    int la[] = {2, 3, 6, 7};
    deletion(la, 4, 2, 100);
    return 0;
}