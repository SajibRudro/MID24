#include <bits/stdc++.h>
using namespace std;
int main() {
    string t, p;
    cin >> t >> p;

    int s = t.length();
    int r = p.length();

    int k = 1;
    int MAX = s - r + 1;
    int index = 0;

    while (k <= MAX) {
        int l;
        for (l = 1; l <= r; l++) {
            if (p[l - 1] != t[k + l - 2]) {
                break;
            }
        }

        if (l > r) {  
            index = k;
            break;
        }

        k = k + 1;
    }

    if (index == 0)
        cout << "INDEX = 0";
    else
        cout << "INDEX = " << index;

    return 0;
}