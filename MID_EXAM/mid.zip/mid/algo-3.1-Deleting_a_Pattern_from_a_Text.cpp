#include <bits/stdc++.h>
using namespace std;

int main() {
    string t, p;

    cin >> t;
    cin >> p;

    int k = t.find(p);

    while (k != -1) {
        t.erase(k, p.length());
        k = t.find(p);
    }

    cout << t;

    return 0;
}