#include <bits/stdc++.h>
using namespace std;
int main()
{
    int n;
    cin >> n;

    int data[n];
    int MAX, LOC;

    for (int i = 0; i < n; i++)
    {
        cin >> data[i];
    }

    MAX = data[0];
    LOC = 1;

    for (int i = 1; i < n; i++)
    {
        if (data[i] > MAX)
        {
            MAX = data[i];
            LOC = i + 1;
        }
    }

    cout << "MAX = " << MAX << endl;
    cout << "LOC = " << LOC << endl;

    return 0;
}