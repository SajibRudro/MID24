#include <iostream>
using namespace std;

// Function to find index of P in T
int findIndex(char T[], int S, char P[], int R) {
    for(int i = 0; i <= S - R; i++) {
        int j;
        for(j = 0; j < R; j++) {
            if(T[i + j] != P[j])
                break;
        }
        if(j == R)
            return i;  // Pattern found
    }
    return -1; // Not found
}

int main() {
    char T[100], P[100];
    int S, R;

    cout << "Enter main string T: ";
    cin >> T;

    cout << "Enter pattern string P: ";
    cin >> P;

    // Calculate lengths manually
    S = 0;
    while(T[S] != '\0') S++;

    R = 0;
    while(P[R] != '\0') R++;

    int index = findIndex(T, S, P, R);

    if(index != -1)
        cout << "Pattern found at index: " << index << endl;
    else
        cout << "Pattern not found." << endl;

    return 0;
}