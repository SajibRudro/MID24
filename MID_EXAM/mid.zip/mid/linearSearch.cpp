#include <bits/stdc++.h>
using namespace std;
void lSearch(int la[], int n, int f)
{
    int flag = 0;
    for (int i = 0; i < n; i++)
    {
        if (la[i] == f)
        {
            cout << "f";
            flag = 1;
            break;
        }
    }

    if (!flag)
    {
        cout << "nf";
    }
}
int main()
{
    int la[] = {2, 3, 6, 7};
    lSearch(la, 4, 10);
    return 0;
}