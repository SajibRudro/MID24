#include <iostream>
#include <stack>
using namespace std;

// Partition function
int partition(int arr[], int low, int high) {
    int pivot = arr[high];
    int i = low - 1;

    for(int j = low; j < high; j++) {
        if(arr[j] <= pivot) {
            i++;
            swap(arr[i], arr[j]);
        }
    }

    swap(arr[i + 1], arr[high]);
    return i + 1;
}

// Iterative QuickSort using stack
void quickSort(int arr[], int n) {
    stack<int> st;

    st.push(0);
    st.push(n - 1);

    while(!st.empty()) {
        int high = st.top(); st.pop();
        int low = st.top(); st.pop();

        int pi = partition(arr, low, high);

        // Left side
        if(pi - 1 > low) {
            st.push(low);
            st.push(pi - 1);
        }

        // Right side
        if(pi + 1 < high) {
            st.push(pi + 1);
            st.push(high);
        }
    }
}

int main() {
    int n;

    cout << "Enter number of elements: ";
    cin >> n;

    int arr[n];

    cout << "Enter elements:\n";
    for(int i = 0; i < n; i++)
        cin >> arr[i];

    quickSort(arr, n);

    cout << "Sorted array:\n";
    for(int i = 0; i < n; i++)
        cout << arr[i] << " ";

    return 0;
}