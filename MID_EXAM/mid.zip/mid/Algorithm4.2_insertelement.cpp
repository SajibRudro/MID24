#include <iostream>
using namespace std;

int main() {
    int LA[10] = {1, 2, 3, 4, 6, 7, 8, 9, 10};
    int ITEM = 5;
    int N = 9;
    int K = 4;

    cout << "Before Inserting:\n";
    for (int i = 0; i < N; i++) {
        cout << LA[i] << " ";
    }

    for (int j = N - 1; j >= K; j--) {
        LA[j + 1] = LA[j];
    }

    LA[K] = ITEM;
    N = N + 1;

    cout << "\nAfter Inserting:\n";
    for (int i = 0; i < N; i++) {
        cout << LA[i] << " ";
    }

    return 0;
}

// inserting at a position