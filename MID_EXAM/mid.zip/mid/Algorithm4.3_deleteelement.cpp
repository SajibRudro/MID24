#include <iostream>
using namespace std;

int main() {
    int LA[] = {1,2,3,4,5,6,7,8,9,10};
    int N = 10;
    int K = 4;

    cout << "Before Deleting:" << endl;
    for (int i = 0; i < N; i++) {
        cout << LA[i] << " ";
    }

    for (int j = K; j < N - 1; j++) {
        LA[j] = LA[j + 1];
    }

    N = N - 1;

    cout << endl << "After Deleting:" << endl;
    for (int i = 0; i < N; i++) {
        cout << LA[i] << " ";
    }

    return 0;
}