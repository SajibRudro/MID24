#include <bits/stdc++.h>
using namespace std;

void insertion(int la[], int n, int k, int item)
{
    int j = n;
    while (j >= k)
    {
        la[j + 1] = la[j];
        j--;
    }
    la[k] = item;
    n = n + 1;
    for (int x = 0; x < n; x++)
    {
        cout << la[x] << " ";
    }
}
int main()
{
    int la[] = {2, 3, 6, 7};
    insertion(la, 4, 2, 100);
    return 0;
}
