#include <bits/stdc++.h>
using namespace std;

int main()
{
    double a, b, c;
    double d, x1, x2, x;

    cin >> a >> b >> c;

    d = (b * b) - (4 * a * c);

    if (d > 0)
    {
        x1 = (-b + sqrt(d)) / (2 * a);
        x2 = (-b - sqrt(d)) / (2 * a);
        cout << x1 << " " << x2;
    }
    else if (d == 0)
    {
        x = -b / (2 * a);
        cout << "UNIQUE SOLUTION " << x;
    }
    else
    {
        cout << "NO REAL SOLUTION";
    }

    return 0;
}