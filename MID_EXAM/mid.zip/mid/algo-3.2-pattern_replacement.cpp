#include <bits/stdc++.h>
using namespace std;
int main() {
    string t, p, q;

    cin >> t;
    cin >> p;
    cin >> q;

    int k = t.find(p);

    while (k != -1) {
        t.replace(k, p.length(), q);
        k = t.find(p);
    }
 
    cout << t;

    return 0;
}