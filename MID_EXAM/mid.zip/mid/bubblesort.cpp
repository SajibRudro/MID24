#include <bits/stdc++.h>
using namespace std;
void bSort(int la[], int n)
{
    for (int i = 0; i < n - 1; i++)
    {
        for (int j = i; j < n; j++)
        {
            if (la[i] > la[j])
            {
                swap(la[i], la[j]);
            }
        }
    }

    for (int i = 0; i < n; i++)
    {
        cout << la[i] << " ";
    }
}
int main()
{
    int la[] = {2, 3, 1, 7,0};
    bSort(la, 5);
    return 0;
}