#include <bits/stdc++.h>
using namespace std;
int main()
{
    int r = 2;
    int cl = 2;
    int num;

    int mat[r][cl];
    // input in array

    // outer loop row
    for (int i = 0; i < r; i++)
    {
        for (int j = 0; j < cl; j++)
        {
            cin >> mat[i][j];
        }
    }

    for (int i = 0; i < r; i++)
    {
        for (int j = 0; j < cl; j++)
        {
            cout << mat[i][j] << " ";
        }
        cout << endl;
    }
    return 0;
}