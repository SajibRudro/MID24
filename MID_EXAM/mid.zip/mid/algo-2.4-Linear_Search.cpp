#include <bits/stdc++.h>
using namespace std;
int main()
{
    int N, ITEM;
    cin >> N;

    int DATA[N];
    for (int i = 0; i < N; i++)
    {
        cin >> DATA[i];
    }

    cin >> ITEM;

    int LOC = 0;

    for (int i = 0; i < N; i++)
    {
        if (DATA[i] == ITEM)
        {
            LOC = i + 1;
            break;
        }
    }

    cout << "LOC = " << LOC;

    return 0;
}